# ARM assembly to HEX file converter

Using the standard GNU ARM assembler for doing this.  You will need
the arm2hex Python code on the repository to run this code.  

For 64-bit linux use:

    ./arm2hex arm-none-eabi-as input_file.s output_file.x

See the lab1 handout on Canvas for further assistance.
